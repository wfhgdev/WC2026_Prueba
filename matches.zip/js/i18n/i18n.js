// i18n Engine for World Cup 2026
// Provides translation functions for all pages
var i18n = (function() {
  'use strict';

  var dict = window.__DICT || {};

  // Generic translation by key
  function t(key) {
    return dict[key] || key;
  }

  // Translate team name from team object or TLA
  function translateTeam(team) {
    var tla = null;
    if (typeof team === 'string') {
      tla = team;
    } else if (team && team.tla) {
      tla = team.tla;
    } else if (team && team.name) {
      // Try to find by English name (fallback)
      return team.name;
    }
    if (tla && dict[tla]) {
      return dict[tla];
    }
    // Fallback to English name or TLA
    return (team && team.name) || tla || '';
  }

  // Translate match status (long form)
  function translateStatus(status) {
    if (!status) return '';
    var key = status.toUpperCase();
    return dict[key] || key;
  }

  // Translate match status (short form)
  function translateStatusShort(status) {
    if (!status) return '';
    var key = status.toUpperCase() + '_SHORT';
    return dict[key] || status;
  }

  // Translate stage name
  function translateStage(stage) {
    if (!stage) return '';
    // Try exact uppercase match
    var key = 'STAGE_' + stage.toUpperCase().replace(/-/g, '_');
    var result = dict[key];
    if (result) return result;
    
    // Try with the stage as-is (some APIs return different formats)
    key = 'STAGE_' + stage.toUpperCase();
    result = dict[key];
    if (result) return result;
    
    // Fallback: clean up the stage string
    return stage.replace(/_/g, ' ').replace(/\b\w/g, function(l) { return l.toUpperCase(); });
  }

  // Translate group name (handles "GROUP_A", "GROUP_1", "A", "1", "Group A" etc.)
  function translateGroup(group, usePrefix) {
    if (!group) return '';
    usePrefix = (usePrefix !== false); // default true
    
    // Extract the group letter/number
    var letter = group;
    if (group.toUpperCase().indexOf('GROUP_') === 0) {
      letter = group.substring(6); // "GROUP_A" → "A"
    } else if (group.toUpperCase().indexOf('GROUP ') === 0) {
      letter = group.substring(6); // "Group A" → "A"
    }
    
    if (usePrefix) {
      var prefix = dict['GROUP_PREFIX'] || 'Group ';
      return prefix + letter;
    }
    return letter;
  }

  // Translate nationality (for scorers table)
  function translateNationality(nationality) {
    if (!nationality) return '';
    // Try team TLA lookup
    if (dict[nationality]) {
      return dict[nationality];
    }
    // Try Intl.DisplayNames as fallback
    try {
      var displayNames = new Intl.DisplayNames(['es'], { type: 'region' });
      var result = displayNames.of(nationality);
      if (result && result !== nationality) return result;
    } catch(e) {
      // Intl not available, fall through
    }
    return nationality;
  }

  // Format a date string to Spanish locale
  function formatDate(dateStr) {
    if (!dateStr) return '';
    try {
      var date = new Date(dateStr);
      if (isNaN(date.getTime())) return dateStr;
      return date.toLocaleDateString('es-ES', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch(e) {
      return dateStr;
    }
  }

  // Format a time string from ISO date
  function formatTime(dateStr) {
    if (!dateStr) return '';
    try {
      var date = new Date(dateStr);
      if (isNaN(date.getTime())) return dateStr;
      return date.toLocaleTimeString('es-ES', {
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch(e) {
      return dateStr;
    }
  }

  // Get relative day label (Hoy, Mañana, Ayer) or formatted date
  function getRelativeDay(dateStr) {
    if (!dateStr) return '';
    try {
      var matchDate = new Date(dateStr);
      if (isNaN(matchDate.getTime())) return dateStr;
      
      var today = new Date();
      // Reset time parts for date comparison
      var todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      var matchDay = new Date(matchDate.getFullYear(), matchDate.getMonth(), matchDate.getDate());
      
      var diffDays = Math.round((matchDay - todayStart) / (1000 * 60 * 60 * 24));
      
      if (diffDays === 0) return t('TODAY');
      if (diffDays === 1) return t('TOMORROW');
      if (diffDays === -1) return t('YESTERDAY');
      
      return matchDate.toLocaleDateString('es-ES', {
        weekday: 'long',
        month: 'long',
        day: 'numeric'
      });
    } catch(e) {
      return dateStr;
    }
  }

  // Get match minute string (e.g., "45'", "En Vivo")
  function getMinuteText(match) {
    if (!match) return '';
    if (match.status === 'IN_PLAY' || match.status === 'PAUSED') {
      if (match.minute) return match.minute + "'";
      return t('LIVE');
    }
    return '';
  }

  return {
    t: t,
    translateTeam: translateTeam,
    translateStatus: translateStatus,
    translateStatusShort: translateStatusShort,
    translateStage: translateStage,
    translateGroup: translateGroup,
    translateNationality: translateNationality,
    formatDate: formatDate,
    formatTime: formatTime,
    getRelativeDay: getRelativeDay,
    getMinuteText: getMinuteText
  };
})();